# Accueil - Préadmission en ligne v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:http://hl7.fr/fhir/fr/preadmission/ImplementationGuide/hl7.fhir.fr.preadmission | *Version*:0.1.0 |
| Draft as of 2025-10-22 | *Computable Name*:PREAD |

### Guide d’implémentation d’InteropSanté

Template du guide d’implémentation d’IS

